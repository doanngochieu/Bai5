package com.example.hello_spring_k8s;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloSpringK8sApplicationTests {

	@Test
	void contextLoads() {
	}

}
